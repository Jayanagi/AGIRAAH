import random
from neural_net import Model

inputs = [
    [1,0,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,0],
    # [0,0.2,1,0,1,0,0.6,1,0,1,0.8,1,0,0.4,0,1,0.6,0,1,0],
    # [1,0,1,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,1,0],
    # [0,0,1,1,1,1,0,1,0,1,0.5,1,0,1,1,0,0,0,1,1],
    # [0,0,1,1,1,1,0,1,0,1,0.5,1,0,1,1,0,0,0,1,0]
]


model = Model()
prompt = "\nChoose an option\n1. Enter input LOV as comma separated values - \n2. Select randomly from pre-defined input\n3. Exit\n"
ip = input(prompt)
while(1):
    if ip == "1":
        lov = input("\nEnter comma separated list of numbers for LOV\n")
        lov_data = [float(i) for i in lov.split(",")]
    elif ip == "2":
        lov_data = random.choice(inputs)
    elif ip == "3":
        exit(0)
    else:
        print(f"unrecognized input - {ip}. Retry")
        continue

    model.process_input(lov_data)
    ip = input(prompt)
