import numpy as np

from constants import pct_weight_increase_on_fire, pct_weight_decrease_at_t, pct_activation_decrease_at_t


class Model:
    def __init__(self):
        self.initial_weights = 0.1
        self.activation_threshold = 0.95
        self.num_hidden_layers = 5

        self.initialize_layers_and_outputs()
        self.initialize_weights()

    def initialize_layers_and_outputs(self):
        self.hidden_layers = [
            np.zeros((20)), # Input
            np.zeros((24)),  # Layer 2
            np.zeros((28)),  # Layer 3
            np.zeros((32)),  # Layer 4
            np.zeros((36)),  # Layer 5
            np.zeros((40)),  # Layer 6
        ]
        self.hidden_layers_t_next = [
            np.zeros((20)), # Input
            np.zeros((24)),  # Layer 2
            np.zeros((28)),  # Layer 3
            np.zeros((32)),  # Layer 4
            np.zeros((36)),  # Layer 5
            np.zeros((40)),  # Layer 6
        ]

        self.output_layer = np.zeros((5))
        self.output_layer_t_next = np.zeros((5))
        self.output_activated = False

    def initialize_weights(self):
        # Initialize weights - Each incoming neuron has 5 weighted connections
        self.weights = [
            np.ones((5, 20)) * self.initial_weights,
            np.ones((5, 24)) * self.initial_weights,
            np.ones((5, 28)) * self.initial_weights,
            np.ones((5, 32)) * self.initial_weights,
            np.ones((5, 36)) * self.initial_weights,
            np.ones((40, 1)) * self.initial_weights
        ]
        # Output layer has 8 neurons from previous layer connected to single output neuron. Each incoming neuron has a single weighted connection
        self.output_weights = np.ones((4,4)) * self.initial_weights


    def initialize_activation_tracker(self):
        self.has_fired = [
            np.zeros((5, 20)),
            np.zeros((5, 24)),
            np.zeros((5, 28)),
            np.zeros((5, 32)),
            np.zeros((5, 36)),
            np.zeros((40, 1))
        ]
        
    def update_weights_on_fire(self, layer, input_layer_size, output_layer_size, out_idx):
        diag_row_start_idx = max(out_idx-input_layer_size+1, 0)
        diag_row_end_idx = min(5, out_idx+1)

        diag_column_end_idx = min(input_layer_size, output_layer_size-out_idx)
        diag_column_start_idx = max(0, diag_column_end_idx-5)
        
        for i, j in zip(
            range(diag_row_start_idx, diag_row_end_idx),
            range(diag_column_start_idx, diag_column_end_idx)
        ):
            self.weights[layer][i, j] = self.weights[layer][i,j]*(1 + pct_weight_increase_on_fire/100)
            self.has_fired[layer][i,j] = 1
    
    def fire_downstram_outputs_and_update_weghts(self, output_index, activation_potential):
        num_output_neurons = self.output_layer.shape[0]
        num_downstream_neurons = len(self.output_layer[output_index+1:])
        for i in range(num_output_neurons-output_index-1):
            next_output_index = output_index+i+1
            weight = self.output_weights[output_index+i, i]
            activation = self.output_layer[next_output_index] + (weight * activation_potential/num_downstream_neurons)            
            self.output_weights[output_index+i][i] = weight * (1-pct_weight_decrease_at_t/100)
            self.output_layer_t_next[next_output_index] += activation

            

    def propagate_single_layer(self, layer=0):
        output_layer = self.hidden_layers[layer+1]
        output_layer_t_next = self.hidden_layers_t_next[layer+1]
        input_layer = self.hidden_layers[layer]
        num_output_neurons = output_layer.shape[0]
        num_input_neurons = input_layer.shape[0]
        for i in range(num_output_neurons):
            min_input_neuron_idx = max(i-4, 0)
            input_neurons = np.array([n/5 if n>self.activation_threshold else 0 for n in input_layer[min_input_neuron_idx:i+1]])
            weights = np.diag(self.weights[layer], num_output_neurons-5-i)
            activation = np.sum(input_neurons*weights)
            
            if output_layer[i] > self.activation_threshold:
                total_activation = activation
            else:
                total_activation = output_layer[i] + activation
                
            # If neuron fires, increase weights of pre-synaptic connection
            if total_activation > self.activation_threshold:
                print(f"Neuron {i+1} in layer {layer+1} fired. Activation = {total_activation}")
                self.update_weights_on_fire(layer, num_input_neurons, num_output_neurons, i)
            
            output_layer_t_next[i] = total_activation
    
    def get_output(self):
        input_layer = self.hidden_layers[-1]
        num_output_neurons = self.output_layer.shape[0]
        for i in range(num_output_neurons):
            min_input_neuron_idx = i*8
            max_input_neuron_idx = min_input_neuron_idx+8
            weights = self.weights[-1][min_input_neuron_idx:max_input_neuron_idx, 0] 
            input_neurons = np.array([n if n>self.activation_threshold else 0 for n in input_layer[min_input_neuron_idx:max_input_neuron_idx]])
            activation = np.sum(input_neurons * weights)

            if self.output_layer[i] >= self.activation_threshold:
                total_activation = activation
                self.output_layer_t_next[i] = 0
                self.fire_downstram_outputs_and_update_weghts(i, self.output_layer[i]-self.activation_threshold)
            else:
                total_activation = self.output_layer[i] + activation
            
            if total_activation > self.activation_threshold:
                # print(f"Output {i+1} fired. Activation = {total_activation}")
                self.weights[-1][min_input_neuron_idx:max_input_neuron_idx, 0] = weights*(1 + pct_weight_increase_on_fire/100)
                self.has_fired[-1][min_input_neuron_idx:max_input_neuron_idx, 0] = 0
            
            self.output_layer_t_next[i] += total_activation

    def update_weights_and_activation(self):
        self.hidden_layers[1:] = self.hidden_layers_t_next[1:].copy()
        self.output_layer = self.output_layer_t_next.copy()

        for i, layer in enumerate(self.hidden_layers[1:]):
            updated_layer = layer * (1-pct_activation_decrease_at_t/100)
            self.hidden_layers[i+1] = np.where(layer>=self.activation_threshold, layer, updated_layer)
        
        for i, has_fired in enumerate(self.has_fired):
            weights = self.weights[i]
            weights = np.where(has_fired, weights, weights*(1-pct_weight_decrease_at_t/100))
            weights = np.where(weights<1, weights, 1)
            self.weights[i] = weights
        
        for i, output in enumerate(self.output_layer):
            updated_output = output * (1-pct_activation_decrease_at_t/100)
            self.output_layer[i] = np.where(output>=self.activation_threshold, output, updated_output)
            if self.output_layer[i] > self.activation_threshold:
                print(f"Output {i} fired. Activation = {self.output_layer[i]}")

        if self.output_layer[-1] > self.activation_threshold:
            print(f"Last output fired with activation of {self.output_layer[-1]}!")
            self.output_activated = True
        
        self.initialize_activation_tracker()

    def propogate_time_step_t(self, t=0):
        print("#"*50)
        if t==7829:
            print("here")
        print(f"t = {t}, input={self.hidden_layers[0]}")
        for i in range(self.num_hidden_layers):
            self.propagate_single_layer(i)
        # At the end of the time step reduce all activations
        self.get_output()
        self.update_weights_and_activation()
    
    def process_input(self, input_data):
        print("*"*50)
        print("*"*50)
        print(f"\n\n\nNew input detected - {input_data}")
        self.initialize_layers_and_outputs()
        self.initialize_activation_tracker()
        self.hidden_layers[0] = np.array(input_data)
        t = 0

        # Run input through iterations and timesteps until output is 1
        while not self.output_activated:
            self.propogate_time_step_t(t=t)
            t += 1