pct_weight_increase_on_fire = 20    
pct_weight_decrease_at_t = 0.1
pct_activation_decrease_at_t = 0.1
