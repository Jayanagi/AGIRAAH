pct_weight_increase_on_fire = 50    
pct_weight_decrease_at_t = 0.0001
pct_activation_decrease_at_t = 0.000000001
