import os
import time
import numpy as np
from csv import writer
import networkx as nx
from networkx.drawing.nx_agraph import graphviz_layout
import matplotlib.pyplot as plt
import pylab

from constants import pct_weight_increase_on_fire, pct_weight_decrease_at_t, pct_activation_decrease_at_t

pylab.ion()
plt.rcParams["figure.figsize"] = (30, 20)
plt.rcParams.update({'font.size': 14})

class Model:
    def __init__(self):
        self.initial_weights = 0.1
        self.activation_threshold = 0.95
        self.num_hidden_layers = 5
        self.num_nodes_per_layer = [20, 24, 28, 32, 36, 40, 5]

        # Graphing
        self.graph = nx.DiGraph()
        self.edges = []
        self.initialize_layers_and_outputs()
        self.initialize_weights()
        self.output_file = f"output_{int(time.time())}.csv"
        # self.output_file = os.path.join("codes", "outputs", f"output_{int(time.time())}.csv")
        with open(self.output_file, 'w') as f:
            csv_writer = writer(f)
            csv_writer.writerow([
                "t", 
                "layer_1_neurons_fired",
                "layer_2_neurons_fired",
                "layer_3_neurons_fired",
                "layer_4_neurons_fired",
                "layer_5_neurons_fired",
                "layer_6_neurons_fired",
                "outputs_fired"
            ])
        self.output_activated = False
        

        

    def initialize_layers_and_outputs(self):
        self.hidden_layers = [
            np.zeros((20)), # Input
            np.zeros((24)),  # Layer 2
            np.zeros((28)),  # Layer 3
            np.zeros((32)),  # Layer 4
            np.zeros((36)),  # Layer 5
            np.zeros((40)),  # Layer 6
        ]
        self.hidden_layers_t_next = [
            np.zeros((20)), # Input
            np.zeros((24)),  # Layer 2
            np.zeros((28)),  # Layer 3
            np.zeros((32)),  # Layer 4
            np.zeros((36)),  # Layer 5
            np.zeros((40)),  # Layer 6
        ]
        self.output_layer = np.zeros((5))
        self.output_layer_t_next = np.zeros((5))
        self.graph.add_nodes_from(list(range(sum(self.num_nodes_per_layer))))

    def initialize_weights(self):
        # Initialize weights - Each incoming neuron has 5 weighted connections
        self.weights = [
            np.ones((5, 20)) * self.initial_weights,
            np.ones((5, 24)) * self.initial_weights,
            np.ones((5, 28)) * self.initial_weights,
            np.ones((5, 32)) * self.initial_weights,
            np.ones((5, 36)) * self.initial_weights,
            np.ones((40, 1)) * self.initial_weights
        ]
        # Output layer has 8 neurons from previous layer connected to single output neuron. Each incoming neuron has a single weighted connection
        self.output_weights = np.ones((4,4)) * self.initial_weights


    def initialize_activation_tracker(self):
        self.has_fired = [
            np.zeros((5, 20)),
            np.zeros((5, 24)),
            np.zeros((5, 28)),
            np.zeros((5, 32)),
            np.zeros((5, 36)),
            np.zeros((40, 1))
        ]
        self.neurons_activated = [
            [], [], [], [], [], [], []
        ]
        self.colors = ["purple"]*sum(self.num_nodes_per_layer)
        self.edges = []

    def get_color_based_on_activation(self, output_activation):
        if output_activation < 0.05:
            return "blue"
        elif output_activation < 0.5:
            return "green"
        elif output_activation < 0.95:
            return "yellow"
        else:
            return "red"
        
    def update_weights_on_fire(self, layer, input_layer_size, output_layer_size, out_idx):
        diag_row_start_idx = max(out_idx-input_layer_size+1, 0)
        diag_row_end_idx = min(5, out_idx+1)

        diag_column_end_idx = min(input_layer_size, output_layer_size-out_idx)
        diag_column_start_idx = max(0, diag_column_end_idx-min(5, out_idx+1))
        
        for i, j in zip(
            range(diag_row_start_idx, diag_row_end_idx),
            range(diag_column_start_idx, diag_column_end_idx)
        ):
            self.weights[layer][i, j] = self.weights[layer][i,j]*(1 + pct_weight_increase_on_fire/100)
            self.has_fired[layer][i,j] = 1
    
    def fire_downstram_outputs_and_update_weghts(self, output_index, activation_potential):
        num_output_neurons = self.output_layer.shape[0]
        num_downstream_neurons = len(self.output_layer[output_index+1:])
        for i in range(num_output_neurons-output_index-1):
            next_output_index = output_index+i+1
            weight = self.output_weights[output_index+i, i]
            activation = self.output_layer[next_output_index] + (weight * activation_potential/num_downstream_neurons)            
            self.output_weights[output_index+i][i] = weight * (1-pct_weight_decrease_at_t/100)
            self.output_layer_t_next[next_output_index] += activation

    def propagate_single_layer(self, layer=0):
        output_layer = self.hidden_layers[layer+1]
        output_layer_t_next = self.hidden_layers_t_next[layer+1]
        input_layer = self.hidden_layers[layer]
        num_output_neurons = output_layer.shape[0]
        num_input_neurons = input_layer.shape[0]
        for i in range(num_output_neurons):
            min_input_neuron_idx = max(i-4, 0)
            input_neurons = np.array([n/5 if n>self.activation_threshold else 0 for n in input_layer[min_input_neuron_idx:i+1]])
            weights = np.diag(self.weights[layer], num_output_neurons-5-i)
            activation = np.sum(input_neurons*weights)
            
            if output_layer[i] > self.activation_threshold:
                total_activation = activation
            else:
                total_activation = output_layer[i] + activation
                
            # If neuron fires, increase weights of pre-synaptic connection
            if total_activation > self.activation_threshold:
                print(f"Neuron {i+1} in layer {layer+1} fired. Activation = {total_activation}")
                self.neurons_activated[layer].append(str(i+1))
                self.update_weights_on_fire(layer, num_input_neurons, num_output_neurons, i)
            
            output_layer_t_next[i] = total_activation
        self.edges.extend(self.build_edges_hidden_layers(layer))
    
    def get_output(self):
        input_layer = self.hidden_layers[-1]
        num_output_neurons = self.output_layer.shape[0]
        for i in range(num_output_neurons):
            min_input_neuron_idx = i*8
            max_input_neuron_idx = min_input_neuron_idx+8
            weights = self.weights[-1][min_input_neuron_idx:max_input_neuron_idx, 0] 
            input_neurons = np.array([n if n>self.activation_threshold else 0 for n in input_layer[min_input_neuron_idx:max_input_neuron_idx]])
            activation = np.sum(input_neurons * weights)

            if self.output_layer[i] >= self.activation_threshold:
                total_activation = activation
                self.output_layer_t_next[i] = 0
                self.fire_downstram_outputs_and_update_weghts(i, self.output_layer[i]-self.activation_threshold)
            else:
                total_activation = self.output_layer[i] + activation
            
            if total_activation > self.activation_threshold:
                # print(f"Output {i+1} fired. Activation = {total_activation}")
                self.weights[-1][min_input_neuron_idx:max_input_neuron_idx, 0] = weights*(1 + pct_weight_increase_on_fire/100)
                self.has_fired[-1][min_input_neuron_idx:max_input_neuron_idx, 0] = 0
            
            self.output_layer_t_next[i] += total_activation
        self.edges.extend(self.build_output_layer_edges())

    def update_weights_and_activation(self, t):
        self.hidden_layers[1:] = self.hidden_layers_t_next[1:].copy()
        self.output_layer = self.output_layer_t_next.copy()
        output_node_index = sum(self.num_nodes_per_layer[:-1])

        for i, layer in enumerate(self.hidden_layers[1:]):
            updated_layer = layer * (1-pct_activation_decrease_at_t/100)
            self.hidden_layers[i+1] = np.where(layer>=self.activation_threshold, layer, updated_layer)
            for j, out in enumerate(layer):
                color = self.get_color_based_on_activation(out)
                node_number = sum(self.num_nodes_per_layer[:i+1]) + j
                self.colors[node_number] = color


        
        for i, has_fired in enumerate(self.has_fired):
            weights = self.weights[i]
            weights = np.where(has_fired, weights, weights*(1-pct_weight_decrease_at_t/100))
            weights = np.where(weights<1, weights, 1)
            self.weights[i] = weights
        
        for i, output in enumerate(self.output_layer):
            updated_output = output * (1-pct_activation_decrease_at_t/100)
            self.output_layer[i] = np.where(output>=self.activation_threshold, output, updated_output)
            color = self.get_color_based_on_activation(self.output_layer[i])
            self.neurons_activated[-1].append(str(i+1))
            self.colors[output_node_index+i] = color
            if self.output_layer[i] > self.activation_threshold:
                print(f"Output {i+1} fired. Activation = {self.output_layer[i]}")
                
        if self.output_layer[-1] > self.activation_threshold:
            print(f"Last output fired with activation of {self.output_layer[-1]}!")
            self.output_activated = True
        
        with open(self.output_file, 'a') as f:
            csv_writer = writer(f)
            csv_writer.writerow([
                t, 
                ", ".join(self.neurons_activated[0]),
                ", ".join(self.neurons_activated[1]),
                ", ".join(self.neurons_activated[2]),
                ", ".join(self.neurons_activated[3]),
                ", ".join(self.neurons_activated[4]),
                ", ".join(self.neurons_activated[5]),
                ", ".join(self.neurons_activated[6]),
            ])

        self.plot_graph(t)
        
        self.initialize_activation_tracker()

    def plot_graph(self, t):
        plt.clf()
        self.graph.add_weighted_edges_from(self.edges)
        pos = graphviz_layout(self.graph, prog='dot', args="-Grankdir=LR")
        plt.title(f't = {t}')
        nx.draw(self.graph,with_labels=True,pos=pos, node_size=[300+(v//99 * 180) for v in self.graph.nodes()], node_color=self.colors)
        elarge = []
        esmall = []
        evsmall = []
        for (u,v,d) in self.graph.edges(data=True):
            if d['weight'] <0.1:
                evsmall.append((u,v))
            elif 0.1<= d['weight'] <=0.5:
                esmall.append((u,v))
            else:
                elarge.append((u,v))

        nx.draw_networkx_edges(self.graph,pos,edgelist=elarge,width=1.5, edge_color='r')
        nx.draw_networkx_edges(self.graph,pos,edgelist=esmall,width=1, alpha=0.2, edge_color="green")
        nx.draw_networkx_edges(self.graph,pos,edgelist=evsmall,width=0.75,alpha=0.9,style='dashed', edge_color='gray')
        plt.pause(0.01)
        pylab.show()

    def build_edges_hidden_layers(self, layer):
        edges = []
        input_nodes_start_idx = sum(self.num_nodes_per_layer[:layer])
        output_nodes_start_idx = sum(self.num_nodes_per_layer[:layer+1])
        unraveled_weights = []
        weights = self.weights[layer]
        for row in weights:
            for w in row[::-1]:
                unraveled_weights.append(w)
        
        for i in range(0, len(unraveled_weights), 5):
            idx = i//5
            weights = unraveled_weights[i:i+5]
            for j,w in enumerate(weights):
                input_idx = input_nodes_start_idx+idx
                output_idx = output_nodes_start_idx+idx+j
                edges.append([input_idx, output_idx, w])
        return edges

    def build_output_layer_edges(self):
        edges = []
        input_nodes_start_idx = sum(self.num_nodes_per_layer[:-2])
        output_nodes_start_idx = sum(self.num_nodes_per_layer[:-1])
        weights = self.weights[-1]
        for i, w in enumerate(weights):
            input_idx = input_nodes_start_idx+i
            output_idx = output_nodes_start_idx +i//8
            edges.append([input_idx, output_idx, w])

        return edges

    def propogate_time_step_t(self, t=0):
        print("#"*50)
        if t==7829:
            print("here")
        print(f"t = {t}, input={self.hidden_layers[0]}")
        for i in range(self.num_hidden_layers):
            self.propagate_single_layer(i)
        # At the end of the time step reduce all activations
        self.get_output()
        self.update_weights_and_activation(t)
    
    def process_input(self, input_data):
        print("*"*50)
        print("*"*50)
        self.output_activated = False
        print(f"\n\n\nNew input detected - {input_data}")
        self.initialize_layers_and_outputs()
        self.initialize_activation_tracker()
        self.hidden_layers[0] = np.array(input_data)
        t = 0

        # Run input through iterations and timesteps until output is 1
        while not self.output_activated:
            self.propogate_time_step_t(t=t)
            t += 1